﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Net;
using System.Net.Sockets;
using Microsoft.Kinect;
using KinectSerializer;
using System.Diagnostics;
using System.Windows.Threading;
using KinectMultiTrack.UI;

namespace KinectMultiTrack
{
    public class Server
    {
        private readonly TcpListener serverKinectTCPListener;
        private readonly Thread serverThread;

        private const uint SEC_IN_MILLISEC = 1000;
        //private const uint WRITE_LOG_INTERVAL = 1/4 * SEC_IN_MILLISEC;
        //private readonly Stopwatch writeLogStopwatch;
        private const int WRITE_FRAME_INTERVAL = 2;
        private int currentFrameCount = 1;
        
        private readonly Tracker tracker;
        private TrackingUI trackingUI;

        public event KinectCameraHandler OnAddedKinect;
        public event KinectCameraHandler OnRemovedKinect;
        public delegate void KinectCameraHandler(IPEndPoint kinectClientIP);

        public Server(int port)
        {
            this.serverKinectTCPListener = new TcpListener(IPAddress.Any, port);
            this.serverThread = new Thread(new ThreadStart(this.ServerWorkerThread));

            this.tracker = new Tracker();

            Thread trackingUIThread = new Thread(new ThreadStart(this.StartTrackingUIThread));
            trackingUIThread.SetApartmentState(ApartmentState.STA);
            trackingUIThread.IsBackground = true;
            trackingUIThread.Start();

            //this.writeLogStopwatch = new Stopwatch();
        }

        private void StartStopServer(bool start)
        {
            if (start)
            {
                this.Run();
            }
            else
            {
                this.Stop();
            }
        }

        private void Run()
        {
            this.serverKinectTCPListener.Start();
            this.serverThread.Start();
            //this.writeLogStopwatch.Start();
            Debug.WriteLine(KinectMultiTrack.Properties.Resources.SERVER_START + this.serverKinectTCPListener.LocalEndpoint);
        }

        private void Stop()
        {
            //this.writeLogStopwatch.Stop();
        }

        private void StartTrackingUIThread()
        {
            this.trackingUI = new TrackingUI();
            this.trackingUI.Show();

            this.trackingUI.OnSetup += this.ConfigureServer;
            this.trackingUI.OnStartStop += this.StartStopServer;
            this.trackingUI.OnDisplayResult += this.Log;

            this.OnAddedKinect += this.trackingUI.Server_AddKinectCamera;
            this.OnRemovedKinect += this.trackingUI.Server_RemoveKinectCamera;
            this.tracker.OnWaitingKinects += this.trackingUI.Tracker_OnWaitingKinects;
            this.tracker.OnCalibration += this.trackingUI.Tracker_OnCalibration;
            this.tracker.OnRecalibration += this.trackingUI.Tracker_OnReCalibration;
            this.tracker.OnResult += this.trackingUI.Tracker_OnResult;

            Dispatcher.Run();
        }

        private void ConfigureServer(int kinectCount, int studyId, int kinectConfiguration)
        {
            this.tracker.Configure(kinectCount);
            if (studyId != Logger.NA)
            {
                Logger.OpenFile(studyId, kinectConfiguration);
            }
        }

        // Accepts connections and for each thread spaw a new connection
        private void ServerWorkerThread()
        {
            while (true)
            {
                TcpClient kinectClient = this.serverKinectTCPListener.AcceptTcpClient();
                Thread kinectFrameThread = new Thread(() => this.ServerKinectFrameWorkerThread(kinectClient));
                kinectFrameThread.Start();
            }
        }

        private void ServerKinectFrameWorkerThread(object obj)
        {
            TcpClient client = obj as TcpClient;
            IPEndPoint clientIP = (IPEndPoint)client.Client.RemoteEndPoint;
            NetworkStream clientStream = client.GetStream();
            Debug.WriteLine(KinectMultiTrack.Properties.Resources.CONNECTION_START + clientIP);
            
            bool kinectCameraAdded = false;

            while (true)
            {
                if (!kinectCameraAdded && this.OnAddedKinect != null)
                {
                    Thread fireOnAddKinectCamera = new Thread(() => this.OnAddedKinect(clientIP));
                    fireOnAddKinectCamera.Start();
                    kinectCameraAdded = true;
                }
                try
                {
                    if (!client.Connected) break;

                    while (!clientStream.DataAvailable) ;

                    SBodyFrame bodyFrame = BodyFrameSerializer.Deserialize(clientStream);
                    this.Track(clientIP, bodyFrame, this.trackingUI.GetCurrentScenarioId());

                    // Response content is trivial
                    byte[] response = Encoding.ASCII.GetBytes(Properties.Resources.SERVER_RESPONSE_OKAY);
                    clientStream.Write(response, 0, response.Length);
                    clientStream.Flush();
                }
                catch (Exception)
                {
                    Debug.WriteLine(KinectMultiTrack.Properties.Resources.SERVER_EXCEPTION);
                    clientStream.Close();
                    client.Close();
                }
            }
            if (kinectCameraAdded)
            {
                this.tracker.RemoveClient(clientIP);
                Thread fireOnRemoveKinectCamera = new Thread(() => this.OnRemovedKinect(clientIP));
                fireOnRemoveKinectCamera.Start();
            }
            clientStream.Close();
            clientStream.Dispose();
            client.Close();
        }

        private void Track(IPEndPoint clientIP, SBodyFrame bodyFrame, int scenarioId)
        {
            Thread track = new Thread(() => this.tracker.SynchronizeTracking(clientIP, bodyFrame, scenarioId));
            track.Start();
        }

        private void Log(TrackerResult result, int userScenario)
        {
            if (this.currentFrameCount == Server.WRITE_FRAME_INTERVAL)
            {
                Thread log = new Thread(() => Logger.SynchronizeLogging(result, userScenario));
                log.Start();
                this.currentFrameCount = 1;
            }
            else
            {
                this.currentFrameCount++;
            }
        }
    }
}
